<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row justify-content-center">
                <div class="col-md-10"><h2>Cliente</h2></div>
                <div class="col-md-2"><a  href="<?php echo e(route('cliente', ['id' => 'novo'])); ?>" class="btn btn-primary">Novo</a></div>
            </div>
            <hr>
            <?php if($showForm): ?>
            <div class="card">
            <div class="card-header">Formulário de Cliente</div>
            <div class="card-body">
            <form action="<?php echo e(route('cliente_cadastrar')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="cpfUpdate" name="cpfUpdate" value="<?php echo e(isset($selecionado->CPF) ? $selecionado->CPF : ''); ?>">
                <div class="form-group">
                    <label for="cpf">CPF:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('cpf') ? ' is-invalid' : ''); ?>" id="cpf" placeholder="Entre com o cpf" name="cpf" value="<?php echo e(isset($selecionado->CPF) ? $selecionado->CPF : old('cpf')); ?>" required>
                    <?php if($errors->has('cpf')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cpf')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('nome') ? ' is-invalid' : ''); ?>" id="nome" placeholder="Entre com o nome" name="nome"  value="<?php echo e(isset($selecionado->NOME) ? $selecionado->NOME : old('nome')); ?>">
                    <?php if($errors->has('nome')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('nome')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>" id="descricao" placeholder="Entre com a descrição" name="descricao"  value="<?php echo e(isset($selecionado->DESCRICAO) ? $selecionado->DESCRICAO : old('descricao')); ?>">
                    <?php if($errors->has('descricao')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('descricao')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Salvar</button>
                <a href="<?php echo e(route('cliente')); ?>" class="btn btn-default">Fechar</a>
            </form>
            </div>
            </div>
            <br>
            <?php endif; ?>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>CPF</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cliente->CPF); ?></td>
                        <td><?php echo e($cliente->NOME); ?></td>
                        <td><?php echo e($cliente->DESCRICAO); ?></td>
                        <td>
                            <a href="<?php echo e(route('cliente', ['id' => $cliente->CPF])); ?>" class="btn btn-success">Editar</a>
                            <a href="<?php echo e(route('cliente_delete', ['id' => $cliente->CPF])); ?>" class="btn btn-danger">Deletar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
                <div><?php echo e($clientes->links()); ?></div>  
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/cliente.blade.php ENDPATH**/ ?>
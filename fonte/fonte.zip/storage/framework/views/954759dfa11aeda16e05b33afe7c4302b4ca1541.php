<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row justify-content-center">
                <div class="col-md-10"><h2>Área/Etapa</h2></div>
                <div class="col-md-2"><a  href="<?php echo e(route('etapa', ['id' => 'novo'])); ?>" class="btn btn-primary">Novo</a></div>
            </div>
            <hr>
            <?php if($showForm): ?>
            <div class="card">
            <div class="card-header">Formulário de Etapa</div>
            <div class="card-body">
            <form action="<?php echo e(route('etapa_cadastrar')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="cod_etapa_update" name="cod_etapa_update" value="<?php echo e(isset($selecionado->cod_etapa) ? $selecionado->cod_etapa : ''); ?>">
                <div class="form-group">
                    <label for="cod_etapa">Código:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('cod_etapa') ? ' is-invalid' : ''); ?>" id="cod_etapa" placeholder="Entre com o cod_etapa" name="cod_etapa" value="<?php echo e(isset($selecionado->cod_etapa) ? $selecionado->cod_etapa : old('cod_etapa')); ?>" required>
                    <?php if($errors->has('cod_etapa')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cod_etapa')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('nome') ? ' is-invalid' : ''); ?>" id="nome" placeholder="Entre com o nome" name="nome"  value="<?php echo e(isset($selecionado->nome) ? $selecionado->nome : old('nome')); ?>">
                    <?php if($errors->has('nome')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('nome')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>" id="descricao" placeholder="Entre com a descrição" name="descricao"  value="<?php echo e(isset($selecionado->descricao) ? $selecionado->descricao : old('descricao')); ?>">
                    <?php if($errors->has('descricao')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('descricao')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="processo">Processo:</label>
                    <select  class="form-control" id="processo" name="processo" >
                        <option value='' selected disabled>Selecione um processo</option>
                        <?php $__currentLoopData = $processos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $processo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($selecionado->cod_proc == $processo->cod_proc): ?>
                            <option value='<?php echo e($processo->cod_proc); ?>' selected><?php echo e($processo->nome); ?></option>
                            <?php else: ?>
                            <option value='<?php echo e($processo->cod_proc); ?>'><?php echo e($processo->nome); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('processo')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('processo')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="area">Área:</label>
                    <select  class="form-control" id="area" name="area" >
                        <option value='' selected disabled>Selecione um área</option>
                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($selecionado->cod_area == $area->cod_area): ?>
                            <option value='<?php echo e($area->cod_area); ?>' selected><?php echo e($area->nome); ?></option>
                            <?php else: ?>
                            <option value='<?php echo e($area->cod_area); ?>'><?php echo e($area->nome); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('area')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('area')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Salvar</button>
                <a href="<?php echo e(route('etapa')); ?>" class="btn btn-default">Fechar</a>
            </form>
            </div>
            </div>
            <br>
            <?php endif; ?>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>Código</th>
                        <th>Porcesso</th>
                        <th>Área</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($etapa->cod_etapa); ?></td>
                        <?php if($etapa->processo): ?>
                            <td><?php echo e($etapa->processo->nome); ?></td>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                        <?php if($etapa->area): ?>
                            <td><?php echo e($etapa->area->nome); ?></td>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                        <td><?php echo e($etapa->nome); ?></td>
                        <td><?php echo e($etapa->descricao); ?></td>
                        <td>
                        <!-- Button to Open the Modal -->
                            <button type="button" class="btn btn-default" data-toggle="modal" 
                                data-target="#<?php echo e($etapa->cod_etapa); ?>">Master Detail
                            </button>
                            <!-- The Modal -->
                            <div class="modal fade" id="<?php echo e($etapa->cod_etapa); ?>">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">

                                    <!-- Modal Header -->
                                    <div class="modal-header">
                                        <h4 class="modal-title">Master Detail - <?php echo e($etapa->nome); ?></h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>

                                    <!-- Modal body -->
                                    <div class="modal-body">
                                        <h5>Área & Processo</h5>
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Tipo</th>
                                                <th>Código Etapa</th>
                                                <th>Código</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                <?php if($etapa->processo): ?>
                                                <tr>
                                                    <td>Processo</td>
                                                    <td><?php echo e($etapa->cod_etapa); ?></td>
                                                    <td><?php echo e($etapa->processo->cod_proc); ?></td>
                                                    <td><?php echo e($etapa->processo->nome); ?></td>
                                                    <td><?php echo e($etapa->processo->descricao); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php if($etapa->area): ?>
                                                <tr>
                                                    <td>Área</td>
                                                    <td><?php echo e($etapa->cod_etapa); ?></td>
                                                    <td><?php echo e($etapa->area->cod_area); ?></td>
                                                    <td><?php echo e($etapa->area->nome); ?></td>
                                                    <td><?php echo e($etapa->area->descricao); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                        <h5>Efs</h5>
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código Etapa</th>
                                                <th>Código Efs</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $etapa->efss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $efs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($etapa->cod_etapa); ?></td>
                                                    <td><?php echo e($efs->cod_efs); ?></td>
                                                    <td><?php echo e($efs->nome); ?></td>
                                                    <td><?php echo e($efs->descricao); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                                    </div>

                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('etapa', ['id' => $etapa->cod_etapa])); ?>" class="btn btn-success">Editar</a>
                            <a href="<?php echo e(route('etapa_delete', ['id' => $etapa->cod_etapa])); ?>" class="btn btn-danger">Deletar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
                <div><?php echo e($etapas->links()); ?></div>  
            </div>
    </div>
    <br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/etapa.blade.php ENDPATH**/ ?>
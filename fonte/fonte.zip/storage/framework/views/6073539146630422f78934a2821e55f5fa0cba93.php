<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row justify-content-center">
                <div class="col-md-10"><h2>Area</h2></div>
                <div class="col-md-2"><a  href="<?php echo e(route('area', ['id' => 'novo'])); ?>" class="btn btn-primary">Novo</a></div>
            </div>
            <hr>
            <?php if($showForm): ?>
            <div class="card">
            <div class="card-header">Formulário de Area</div>
            <div class="card-body">
            <form action="<?php echo e(route('area_cadastrar')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="cod_area_update" name="cod_area_update" value="<?php echo e(isset($selecionado->cod_area) ? $selecionado->cod_area : ''); ?>">
                <div class="form-group">
                    <label for="cod_area">Código:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('cod_area') ? ' is-invalid' : ''); ?>" id="cod_area" placeholder="Entre com o cod_area" name="cod_area" value="<?php echo e(isset($selecionado->cod_area) ? $selecionado->cod_area : old('cod_area')); ?>" required>
                    <?php if($errors->has('cod_area')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cod_area')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('nome') ? ' is-invalid' : ''); ?>" id="nome" placeholder="Entre com o nome" name="nome"  value="<?php echo e(isset($selecionado->nome) ? $selecionado->nome : old('nome')); ?>">
                    <?php if($errors->has('nome')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('nome')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>" id="descricao" placeholder="Entre com a descrição" name="descricao"  value="<?php echo e(isset($selecionado->descricao) ? $selecionado->descricao : old('descricao')); ?>">
                    <?php if($errors->has('descricao')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('descricao')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Salvar</button>
                <a href="<?php echo e(route('area')); ?>" class="btn btn-default">Fechar</a>
            </form>
            </div>
            </div>
            <br>
            <?php endif; ?>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($area->cod_area); ?></td>
                        <td><?php echo e($area->nome); ?></td>
                        <td><?php echo e($area->descricao); ?></td>
                        <td>
                        <!-- Button to Open the Modal -->
                            <button type="button" class="btn btn-default" data-toggle="modal" 
                                data-target="#<?php echo e($area->cod_area); ?>">Ver Etapas
                            </button>
                            <!-- The Modal -->
                            <div class="modal fade" id="<?php echo e($area->cod_area); ?>">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">

                                    <!-- Modal Header -->
                                    <div class="modal-header">
                                        <h4 class="modal-title">Etapas - <?php echo e($area->nome); ?></h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>

                                    <!-- Modal body -->
                                    <div class="modal-body">
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código Etapa</th>
                                                <th>Código Processo</th>
                                                <th>Código Área</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $area->etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($etapa->cod_etapa); ?></td>
                                                <td><?php echo e($etapa->cod_proc); ?></td>
                                                <td><?php echo e($etapa->cod_area); ?></td>
                                                <td><?php echo e($etapa->nome); ?></td>
                                                <td><?php echo e($etapa->descricao); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                                    </div>

                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('area', ['id' => $area->cod_area])); ?>" class="btn btn-success">Editar</a>
                            <a href="<?php echo e(route('area_delete', ['id' => $area->cod_area])); ?>" class="btn btn-danger">Deletar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
                <div><?php echo e($areas->links()); ?></div>  
            </div>
    </div>
    <br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/area.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row justify-content-center">
                <div class="col-md-10"><h2>Projeto</h2></div>
                <div class="col-md-2"><a  href="<?php echo e(route('projeto', ['id' => 'novo'])); ?>" class="btn btn-primary">Novo</a></div>
            </div>
            <hr>
            <?php if($showForm): ?>
            <div class="card">
            <div class="card-header">Formulário de Projeto</div>
            <div class="card-body">
            <form action="<?php echo e(route('projeto_cadastrar')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="cod_projeto_update" name="cod_projeto_update" value="<?php echo e(isset($selecionado->cod_projeto) ? $selecionado->cod_projeto : ''); ?>">
                <div class="form-group">
                    <label for="cod_projeto">Código:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('cod_projeto') ? ' is-invalid' : ''); ?>" id="cod_projeto" placeholder="Entre com o cod_projeto" name="cod_projeto" value="<?php echo e(isset($selecionado->cod_projeto) ? $selecionado->cod_projeto : old('cod_projeto')); ?>" required>
                    <?php if($errors->has('cod_projeto')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cod_projeto')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('nome') ? ' is-invalid' : ''); ?>" id="nome" placeholder="Entre com o nome" name="nome"  value="<?php echo e(isset($selecionado->nome) ? $selecionado->nome : old('nome')); ?>">
                    <?php if($errors->has('nome')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('nome')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>" id="descricao" placeholder="Entre com a descrição" name="descricao"  value="<?php echo e(isset($selecionado->descricao) ? $selecionado->descricao : old('descricao')); ?>">
                    <?php if($errors->has('descricao')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('descricao')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="cpf">Cliente:</label>
                    <select  class="form-control" id="cpf" name="cpf" >
                        <option value='' selected disabled>Selecione um Cliente</option>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($selecionado->cpf == $cliente->CPF): ?>
                                <option value='<?php echo e($cliente->CPF); ?>' selected><?php echo e($cliente->NOME); ?></option>
                            <?php else: ?>
                                <option value='<?php echo e($cliente->CPF); ?>'><?php echo e($cliente->NOME); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('cpf')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cpf')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Salvar</button>
                <a href="<?php echo e(route('projeto')); ?>" class="btn btn-default">Fechar</a>
            </form>
            </div>
            </div>
            <br>
            <?php endif; ?>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $projetos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projeto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($projeto->cod_projeto); ?></td>
                        <td><?php echo e($projeto->nome); ?></td>
                        <td><?php echo e($projeto->descricao); ?></td>
                        <td><?php echo e($projeto->cpf); ?></td>
                        <td>
                        <!-- Button to Open the Modal -->
                            <button type="button" class="btn btn-default" data-toggle="modal" 
                                data-target="#<?php echo e($projeto->cod_projeto); ?>">Master Detail
                            </button>
                            <!-- The Modal -->
                            <div class="modal fade" id="<?php echo e($projeto->cod_projeto); ?>">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">

                                    <!-- Modal Header -->
                                    <div class="modal-header">
                                        <h4 class="modal-title">Master Detail - <?php echo e($projeto->nome); ?></h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>

                                    <!-- Modal body -->
                                    <div class="modal-body">
                                        <h5>Fase</h5>
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código Fase</th>
                                                <th>Inicio</th>
                                                <th>Fim</th>
                                                <th>Descrição</th>
                                                <th>Código Projeto</th>
                                                <th>Código Processo</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $projeto->fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($fase->cod_fase); ?></td>
                                                <td><?php echo e($fase->dt_ini); ?></td>
                                                <td><?php echo e($fase->dt_fim); ?></td>
                                                <td><?php echo e($fase->descricao); ?></td>
                                                <td><?php echo e($fase->cod_projeto); ?></td>
                                                <td><?php echo e($fase->cod_proc); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <h5>Cliente</h5>
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código Cliente</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td><?php echo e($projeto->cpf); ?></td>
                                                <td><?php echo e($projeto->cliente->NOME); ?></td>
                                                <td><?php echo e($projeto->cliente->DESCRICAO); ?></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                                    </div>

                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('projeto', ['id' => $projeto->cod_projeto])); ?>" class="btn btn-success">Editar</a>
                            <a href="<?php echo e(route('projeto_delete', ['id' => $projeto->cod_projeto])); ?>" class="btn btn-danger">Deletar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
                <div><?php echo e($projetos->links()); ?></div>  
            </div>
    </div>
    <br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/projeto.blade.php ENDPATH**/ ?>
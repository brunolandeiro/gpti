<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <h2>Relatório</h2>
            <h5>Área/Etapa/Processo/EFS<h5>
            <hr>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th class="alert-danger">Nome Etapa</th>
                        <th class="alert-danger">Descrição Etapa</th>
                        <th>Nome Processo</th>
                        <th>Descrição Processo</th>
                        <th class="alert-success">Nome Área</th>
                        <th class="alert-success">Descrição Área</th>
                        <th>Nome Efs</th>
                        <th>Descrição Efs</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $relatorio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($r->nome); ?></td>
                        <td><?php echo e($r->descricao); ?></td>
                        <td><?php echo e($r->pnome); ?></td>
                        <td><?php echo e($r->pdescricao); ?></td>
                        <td><?php echo e($r->anome); ?></td>
                        <td><?php echo e($r->adescricao); ?></td>
                        <td><?php echo e($r->efsanome); ?></td>
                        <td><?php echo e($r->efsadescricao); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
            </div>
    </div>
    <br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/relatorio/area_etapa_processo_efs.blade.php ENDPATH**/ ?>
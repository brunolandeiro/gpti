<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row justify-content-center">
                <div class="col-md-10"><h2>Projeto/Fase</h2></div>
                <div class="col-md-2"><a  href="<?php echo e(route('fase', ['id' => 'novo'])); ?>" class="btn btn-primary">Novo</a></div>
            </div>
            <hr>
            <?php if($showForm): ?>
            <div class="card">
            <div class="card-header">Formulário de Fase</div>
            <div class="card-body">
            <form action="<?php echo e(route('fase_cadastrar')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="cod_fase_update" name="cod_fase_update" value="<?php echo e(isset($selecionado->cod_fase) ? $selecionado->cod_fase : ''); ?>">
                <div class="form-group">
                    <label for="cod_fase">Código:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('cod_fase') ? ' is-invalid' : ''); ?>" id="cod_fase" placeholder="Entre com o cod_fase" name="cod_fase" value="<?php echo e(isset($selecionado->cod_fase) ? $selecionado->cod_fase : old('cod_fase')); ?>" required>
                    <?php if($errors->has('cod_fase')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cod_fase')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="dt_ini">Data Inicio:</label>
                    <input type="date" class="form-control<?php echo e($errors->has('dt_ini') ? ' is-invalid' : ''); ?>" id="dt_ini" placeholder="Entre com o dt_ini" name="dt_ini"  value="<?php echo e(isset($selecionado->dt_ini) ? $selecionado->dt_ini : old('dt_ini')); ?>">
                    <?php if($errors->has('dt_ini')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('dt_ini')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="dt_fim">Data Fim:</label>
                    <input type="date" class="form-control<?php echo e($errors->has('dt_fim') ? ' is-invalid' : ''); ?>" id="dt_fim" placeholder="Entre com a descrição" name="dt_fim"  value="<?php echo e(isset($selecionado->dt_fim) ? $selecionado->dt_fim : old('dt_fim')); ?>">
                    <?php if($errors->has('dt_fim')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('dt_fim')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>" id="descricao" placeholder="Entre com a descrição" name="descricao"  value="<?php echo e(isset($selecionado->descricao) ? $selecionado->descricao : old('descricao')); ?>">
                    <?php if($errors->has('descricao')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('descricao')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="cod_projeto">Projeto:</label>
                    <select  class="form-control" id="cod_projeto" name="cod_projeto" >
                        <option value='' selected disabled>Selecione um Projeto</option>
                            <?php $__currentLoopData = $projetos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projeto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($selecionado->cod_projeto == $projeto->cod_projeto): ?>
                                <option value='<?php echo e($projeto->cod_projeto); ?>' selected><?php echo e($projeto->nome); ?></option>
                            <?php else: ?>
                                <option value='<?php echo e($projeto->cod_projeto); ?>'><?php echo e($projeto->nome); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('cod_projeto')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cod_projeto')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="cod_proc">Processo:</label>
                    <select  class="form-control" id="cod_proc" name="cod_proc" >
                        <option value='' selected disabled>Selecione um Processo</option>
                            <?php $__currentLoopData = $processos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $processo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($selecionado->cod_proc == $processo->cod_proc): ?>
                                <option value='<?php echo e($processo->cod_proc); ?>' selected><?php echo e($processo->nome); ?></option>
                            <?php else: ?>
                                <option value='<?php echo e($processo->cod_proc); ?>'><?php echo e($processo->nome); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('cod_proc')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cod_proc')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Salvar</button>
                <a href="<?php echo e(route('fase')); ?>" class="btn btn-default">Fechar</a>
            </form>
            </div>
            </div>
            <br>
            <?php endif; ?>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>Código</th>
                        <th>Data Inicio</th>
                        <th>Data Fim</th>
                        <th>Descrição</th>
                        <th>Projeto</th>
                        <th>Processo</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($fase->cod_fase); ?></td>
                        <td><?php echo e($fase->dt_ini); ?></td>
                        <td><?php echo e($fase->dt_fim); ?></td>
                        <td><?php echo e($fase->descricao); ?></td>
                        <td><?php echo e($fase->cod_projeto); ?></td>
                        <td><?php echo e($fase->cod_proc); ?></td>
                        <td>
                        <!-- Button to Open the Modal -->
                            <button type="button" class="btn btn-default" data-toggle="modal" 
                                data-target="#<?php echo e($fase->cod_fase); ?>">Master Detail
                            </button>
                            <!-- The Modal -->
                            <div class="modal fade" id="<?php echo e($fase->cod_fase); ?>">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">

                                    <!-- Modal Header -->
                                    <div class="modal-header">
                                        <h4 class="modal-title">Master Detail - <?php echo e($fase->descricao); ?></h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>

                                    <!-- Modal body -->
                                    <div class="modal-body">
                                        <h5>Projeto</h5>
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                                <th>CPF</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td><?php echo e($fase->projeto->cod_projeto); ?></td>
                                                <td><?php echo e($fase->projeto->nome); ?></td>
                                                <td><?php echo e($fase->projeto->descricao); ?></td>
                                                <td><?php echo e($fase->projeto->cpf); ?></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                        <h5>Processo</h5>
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td><?php echo e($fase->cod_proc); ?></td>
                                                <td><?php echo e($fase->projeto->nome); ?></td>
                                                <td><?php echo e($fase->projeto->descricao); ?></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                                    </div>

                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('fase', ['id' => $fase->cod_fase])); ?>" class="btn btn-success">Editar</a>
                            <a href="<?php echo e(route('fase_delete', ['id' => $fase->cod_fase])); ?>" class="btn btn-danger">Deletar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
                <div><?php echo e($fases->links()); ?></div>  
            </div>
    </div>
    <br>
</div>
<script>
$('#dt_ini').mask('99/99/9999',{placeholder:"dd/mm/yyyy"});
$('#dt_fim').mask('99/99/9999',{placeholder:"dd/mm/yyyy"});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/fase.blade.php ENDPATH**/ ?>
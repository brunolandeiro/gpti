<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row justify-content-center">
                <div class="col-md-10"><h2>EFS/Etapa</h2></div>
                <div class="col-md-2"><a  href="<?php echo e(route('efs_etapa', ['cod_efs' => 'novo'])); ?>" class="btn btn-primary">Novo</a></div>
            </div>
            <hr>
            <?php if($showForm): ?>
                <div class="card">
                <div class="card-header">Formulário de Efs/Etapa</div>
                <div class="card-body">
                    <form action="<?php echo e(route('efs_etapa_cadastrar')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" id="cod_efs_update" name="cod_efs_update" value="<?php echo e(isset($selecionado->cod_efs) ? $selecionado->cod_efs : ''); ?>">       
                        <input type="hidden" id="cod_etapa_update" name="cod_etapa_update" value="<?php echo e(isset($selecionado->cod_etapa) ? $selecionado->cod_etapa : ''); ?>">
                        <div class="form-group">
                            <label for="efs">Efs:</label>
                            <select  class="form-control" id="cod_efs" name="cod_efs" >
                                <option value='' selected disabled>Selecione um efs</option>
                                <?php $__currentLoopData = $efss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $efs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($selecionado->cod_efs == $efs->cod_efs): ?>
                                    <option value='<?php echo e($efs->cod_efs); ?>' selected><?php echo e($efs->nome); ?></option>
                                    <?php else: ?>
                                    <option value='<?php echo e($efs->cod_efs); ?>'><?php echo e($efs->nome); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('efs')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('efs')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="etapa">Etapa:</label>
                            <select  class="form-control" id="cod_etapa" name="cod_etapa" >
                                <option value='' selected disabled>Selecione um área</option>
                                <?php $__currentLoopData = $etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($selecionado->cod_etapa == $etapa->cod_etapa): ?>
                                    <option value='<?php echo e($etapa->cod_etapa); ?>' selected><?php echo e($etapa->nome); ?></option>
                                    <?php else: ?>
                                    <option value='<?php echo e($etapa->cod_etapa); ?>'><?php echo e($etapa->nome); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('etapa')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('etapa')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="tipo">Tipo:</label>
                            <input type="text" class="form-control<?php echo e($errors->has('tipo') ? ' is-invalid' : ''); ?>" id="tipo" placeholder="Entre com o tipo" name="tipo" value="<?php echo e(isset($selecionado->tipo) ? $selecionado->tipo : old('tipo')); ?>" required>
                            <?php if($errors->has('tipo')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('tipo')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                        <a href="<?php echo e(route('efs_etapa')); ?>" class="btn btn-default">Fechar</a>
                    </form>
                </div>
                </div>
                <br>
            <?php endif; ?>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>Código EFS</th>
                        <th>Código Etapa</th>
                        <th>Tipo</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $efs_etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $efs_etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($efs_etapa->cod_efs); ?></td>
                        <td><?php echo e($efs_etapa->cod_etapa); ?></td>
                        <td><?php echo e($efs_etapa->tipo); ?></td>
                        <td>
                        <!-- Button to Open the Modal -->
                        <button type="button" class="btn btn-default" data-toggle="modal" 
                            data-target="#<?php echo e($efs_etapa->cod_efs); ?><?php echo e($efs_etapa->cod_etapa); ?>">Master Detail
                        </button>
                        <!-- The Modal -->
                        <div class="modal fade" id="<?php echo e($efs_etapa->cod_efs); ?><?php echo e($efs_etapa->cod_etapa); ?>">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">

                                    <!-- Modal Header -->
                                    <div class="modal-header">
                                        <h4 class="modal-title">Master Detail</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>

                                    <!-- Modal body -->
                                    <div class="modal-body">
                                        <h5>Etapas</h5>
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código Etapa</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $efs_etapa->etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($etapa->cod_etapa); ?></td>
                                                <td><?php echo e($etapa->nome); ?></td>
                                                <td><?php echo e($etapa->descricao); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <h5>EFS</h5>
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código EFS</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $efs_etapa->efss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $efs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($efs->cod_efs); ?></td>
                                                <td><?php echo e($efs->nome); ?></td>
                                                <td><?php echo e($efs->descricao); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                                    </div>

                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('efs_etapa', ['cod_efs' => $efs_etapa->cod_efs, 'cod_etapa' => $efs_etapa->cod_etapa] )); ?>" class="btn btn-success">Editar</a>
                            <a href="<?php echo e(route('efs_etapa_delete', ['cod_efs' => $efs_etapa->cod_efs, 'cod_etapa' => $efs_etapa->cod_etapa] )); ?>" class="btn btn-danger">Excluir</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
            </div>
    </div>
    <br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/efs_etapa.blade.php ENDPATH**/ ?>
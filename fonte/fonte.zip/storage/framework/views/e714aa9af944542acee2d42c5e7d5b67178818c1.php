<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row justify-content-center">
                <div class="col-md-10"><h2>Processo</h2></div>
                <div class="col-md-2"><a  href="<?php echo e(route('processo', ['id' => 'novo'])); ?>" class="btn btn-primary">Novo</a></div>
            </div>
            <hr>
            <?php if($showForm): ?>
            <div class="card">
            <div class="card-header">Formulário de Processo</div>
            <div class="card-body">
            <form action="<?php echo e(route('processo_cadastrar')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="cod_proc_update" name="cod_proc_update" value="<?php echo e(isset($selecionado->cod_proc) ? $selecionado->cod_proc : ''); ?>">
                <div class="form-group">
                    <label for="cod_proc">Código:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('cod_proc') ? ' is-invalid' : ''); ?>" id="cod_proc" placeholder="Entre com o cod_proc" name="cod_proc" value="<?php echo e(isset($selecionado->cod_proc) ? $selecionado->cod_proc : old('cod_proc')); ?>" required>
                    <?php if($errors->has('cod_proc')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cod_proc')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('nome') ? ' is-invalid' : ''); ?>" id="nome" placeholder="Entre com o nome" name="nome"  value="<?php echo e(isset($selecionado->nome) ? $selecionado->nome : old('nome')); ?>">
                    <?php if($errors->has('nome')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('nome')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>" id="descricao" placeholder="Entre com a descrição" name="descricao"  value="<?php echo e(isset($selecionado->descricao) ? $selecionado->descricao : old('descricao')); ?>">
                    <?php if($errors->has('descricao')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('descricao')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Salvar</button>
                <a href="<?php echo e(route('processo')); ?>" class="btn btn-default">Fechar</a>
            </form>
            </div>
            </div>
            <br>
            <?php endif; ?>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $processos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $processo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($processo->cod_proc); ?></td>
                        <td><?php echo e($processo->nome); ?></td>
                        <td><?php echo e($processo->descricao); ?></td>
                        <td>
                        <!-- Button to Open the Modal -->
                            <button type="button" class="btn btn-default" data-toggle="modal" 
                                data-target="#<?php echo e($processo->cod_proc); ?>">Ver Etapas
                            </button>
                            <!-- The Modal -->
                            <div class="modal fade" id="<?php echo e($processo->cod_proc); ?>">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">

                                    <!-- Modal Header -->
                                    <div class="modal-header">
                                        <h4 class="modal-title">Etapas - <?php echo e($processo->nome); ?></h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>

                                    <!-- Modal body -->
                                    <div class="modal-body">
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código Etapa</th>
                                                <th>Código Processo</th>
                                                <th>Código Área</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $processo->etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($etapa->cod_etapa); ?></td>
                                                <td><?php echo e($etapa->cod_proc); ?></td>
                                                <td><?php echo e($etapa->cod_area); ?></td>
                                                <td><?php echo e($etapa->nome); ?></td>
                                                <td><?php echo e($etapa->descricao); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                                    </div>

                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('processo', ['id' => $processo->cod_proc])); ?>" class="btn btn-success">Editar</a>
                            <a href="<?php echo e(route('processo_delete', ['id' => $processo->cod_proc])); ?>" class="btn btn-danger">Deletar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
                <div><?php echo e($processos->links()); ?></div>  
            </div>
    </div>
    <br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/processo.blade.php ENDPATH**/ ?>
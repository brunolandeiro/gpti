<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="row justify-content-center">
                <div class="col-md-10"><h2>Efs</h2></div>
                <div class="col-md-2"><a  href="<?php echo e(route('efs', ['id' => 'novo'])); ?>" class="btn btn-primary">Novo</a></div>
            </div>
            <hr>
            <?php if($showForm): ?>
            <div class="card">
            <div class="card-header">Formulário de Efs</div>
            <div class="card-body">
            <form action="<?php echo e(route('efs_cadastrar')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="cod_efs_update" name="cod_efs_update" value="<?php echo e(isset($selecionado->cod_efs) ? $selecionado->cod_efs : ''); ?>">
                <div class="form-group">
                    <label for="cod_efs">Código:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('cod_efs') ? ' is-invalid' : ''); ?>" id="cod_efs" placeholder="Entre com o cod_efs" name="cod_efs" value="<?php echo e(isset($selecionado->cod_efs) ? $selecionado->cod_efs : old('cod_efs')); ?>" required>
                    <?php if($errors->has('cod_efs')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cod_efs')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('nome') ? ' is-invalid' : ''); ?>" id="nome" placeholder="Entre com o nome" name="nome"  value="<?php echo e(isset($selecionado->nome) ? $selecionado->nome : old('nome')); ?>">
                    <?php if($errors->has('nome')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('nome')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <input type="text" class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>" id="descricao" placeholder="Entre com a descrição" name="descricao"  value="<?php echo e(isset($selecionado->descricao) ? $selecionado->descricao : old('descricao')); ?>">
                    <?php if($errors->has('descricao')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('descricao')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="etapas">Etapa:</label>
                    <select class="form-control" multiple="multiple" name="etapas[]" id="etapas">
                        <?php $__currentLoopData = $etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($etapa->cod_etapa); ?>" ><?php echo e($etapa->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('etapas')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('etapas')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div id="etapas">
                <div>
                <button type="submit" class="btn btn-primary">Salvar</button>
                <a href="<?php echo e(route('efs')); ?>" class="btn btn-default">Fechar</a>
            </form>
            </div>
            </div>
            <br>
            <?php endif; ?>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $efss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $efs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($efs->cod_efs); ?></td>
                        <td><?php echo e($efs->nome); ?></td>
                        <td><?php echo e($efs->descricao); ?></td>
                        <td>
                        <!-- Button to Open the Modal -->
                            <button type="button" class="btn btn-default" data-toggle="modal" 
                                data-target="#<?php echo e($efs->cod_efs); ?>">Ver Etapas
                            </button>
                            <!-- The Modal -->
                            <div class="modal fade" id="<?php echo e($efs->cod_efs); ?>">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">

                                    <!-- Modal Header -->
                                    <div class="modal-header">
                                        <h4 class="modal-title">Etapas - <?php echo e($efs->nome); ?></h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>

                                    <!-- Modal body -->
                                    <div class="modal-body">
                                        <table class="table table-hover">
                                            <thead>
                                            <tr>
                                                <th>Código Etapa</th>
                                                <th>Código Processo</th>
                                                <th>Código Área</th>
                                                <th>Nome</th>
                                                <th>Descrição</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $efs->etapas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etapa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($etapa->cod_etapa); ?></td>
                                                <td><?php echo e($etapa->cod_proc); ?></td>
                                                <td><?php echo e($etapa->cod_area); ?></td>
                                                <td><?php echo e($etapa->nome); ?></td>
                                                <td><?php echo e($etapa->descricao); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Modal footer -->
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                                    </div>

                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('efs', ['id' => $efs->cod_efs])); ?>" class="btn btn-success">Editar</a>
                            <a href="<?php echo e(route('efs_delete', ['id' => $efs->cod_efs])); ?>" class="btn btn-danger">Deletar</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
                <div><?php echo e($efss->links()); ?></div>  
            </div>
    </div>
    <br>
</div>


<script>
$('#etapa').onchange(function(){
    console.log($('#etapa'));
})
<script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/efs.blade.php ENDPATH**/ ?>
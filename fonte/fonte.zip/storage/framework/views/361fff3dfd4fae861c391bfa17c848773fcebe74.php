<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <h2>Relatório</h2>
            <h5>Efs/Etapa<h5>
            <hr>
            <div class="card">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th class="alert-danger">Nome Etapa</th>
                        <th class="alert-danger">Descrição Etapa</th>
                        <th>Tipo</th>
                        <th>Código Processo</th>
                        <th class="alert-success">Nome EFS</th>
                        <th class="alert-success">Descrição EFS</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $relatorio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($r->enome); ?></td>
                        <td><?php echo e($r->edescricao); ?></td>
                        <td><?php echo e($r->tipo); ?></td>
                        <td><?php echo e($r->cod_proc); ?></td>
                        <td><?php echo e($r->efsnome); ?></td>
                        <td><?php echo e($r->efsdescricao); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="row justify-content-center">
            </div>
    </div>
    <br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bruno\projetos\faculdade\gestao-projeto\gpti\fonte\resources\views/relatorio/relatorio_efs_etapa.blade.php ENDPATH**/ ?>